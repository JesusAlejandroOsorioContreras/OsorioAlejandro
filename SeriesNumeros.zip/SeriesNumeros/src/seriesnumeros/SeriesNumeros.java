package seriesnumeros;

import java.util.Scanner;

    public class SeriesNumeros {
        
        public void Fibonacci(int a, int b, int c, int lim){
            
            for(int i = 0; i < lim; i++){
                
                System.out.print(a + ", ");
                c = a + b;
                a = b;
                b = c;
            }
        }
        
        public void Padovan(int lim){
           
            long padovan [] = new long[lim];
            padovan[0] = padovan[1] = padovan[2] = 1;
            System.out.print(padovan[0] + ", " + padovan[1] + ", " + padovan[2] + ", ");
            
            for(int i = 3; i < lim; i++){
            
                padovan[i] = padovan[i - 2] + padovan[i - 3];
                System.out.print(padovan[i] + ", ");
            }
        }

    public static void main(String[] args) {
        
        SeriesNumeros metodo = new SeriesNumeros();
        Scanner sc = new Scanner(System.in);
        
        int a = 0, b = 1, c = 0, lim, seleccion;
        
        System.out.println("¿Qué serie desea imprimir?");
        System.out.println("Fibonacci = 1 / Padovan = 2");
        seleccion = sc.nextInt();
        System.out.println("Límite de la serie: ");
        lim = sc.nextInt();
        System.out.println("Serie: ");
        
        if(seleccion == 1){
            metodo.Fibonacci(a,b,c,lim);
        }
        
        else{
            metodo.Padovan(lim);
        }
    }
}
